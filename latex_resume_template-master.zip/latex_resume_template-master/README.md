# Minimalist Latex Resume Template

![image](https://user-images.githubusercontent.com/17241029/119233630-009ee080-baf8-11eb-9214-175bc8019b61.png)

# Setup Process

### Install Latex
https://miktex.org/download

### Install Latex Editor
Texmaker is a good latex editor:
https://www.xm1math.net/texmaker/

### Edit
Open (or make a copy of) `resume_template.tex`, customize the file as you wish, and, finally, compile.


